"""Conservative PPTX draft extraction. Requires Pillow. Never overwrites output."""
import argparse
import hashlib
import io
import json
import posixpath
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from PIL import Image, ImageOps

NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}

def relationships(z, part):
    rel = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part) + '.rels')
    if rel not in z.namelist():
        return {}
    result = {}
    for item in ET.fromstring(z.read(rel)):
        if item.get('TargetMode') == 'External':
            continue
        target = item.get('Target', '')
        target = posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(posixpath.dirname(part), target))
        if target.startswith('../'):
            raise ValueError('Relationship escapes archive')
        result[item.get('Id')] = (item.get('Type', '').split('/')[-1], target)
    return result

def extract(src, output, book_id, title):
    if not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*', book_id):
        raise ValueError('Invalid stable book id')
    if output.exists():
        raise FileExistsError('Refusing to overwrite ' + str(output))
    with zipfile.ZipFile(src) as z:
        if sum(x.file_size for x in z.infolist()) > 512 * 1024 * 1024:
            raise ValueError('Archive too large; review manually')
        pres = ET.fromstring(z.read('ppt/presentation.xml'))
        rels = relationships(z, 'ppt/presentation.xml')
        ordered = [rels[x.get('{'+NS['r']+'}id')][1] for x in pres.findall('p:sldIdLst/p:sldId', NS)]
        output.mkdir(parents=True)
        (output / 'images').mkdir()
        (output / 'audio').mkdir()
        pages, evidence = [], []
        for i, part in enumerate(ordered, 1):
            tree, rel = ET.fromstring(z.read(part)), relationships(z, part)
            pid = f'p{i:03d}'
            paragraphs = [''.join(t.text or '' for t in p.findall('.//a:t', NS)).strip() for p in tree.findall('.//a:p', NS)]
            text = ' '.join(p for p in paragraphs if p)
            pics, warnings = [], []
            for pic in tree.findall('.//p:pic', NS):
                blip = pic.find('.//a:blip', NS)
                rid = blip.get('{'+NS['r']+'}embed') if blip is not None else None
                if rid not in rel or rel[rid][0] != 'image':
                    continue
                target = rel[rid][1]
                try:
                    im = Image.open(io.BytesIO(z.read(target)))
                    w, h = im.size
                    if w < 64 or h < 64:
                        continue
                    extent = pic.find('.//a:xfrm/a:ext', NS)
                    area = int(extent.get('cx', '0')) * int(extent.get('cy', '0')) if extent is not None else w*h
                    pics.append((area, target, w, h))
                    if pic.find('.//a:srcRect', NS) is not None:
                        warnings.append('Picture crop present: inspect rendered slide')
                    xf = pic.find('.//a:xfrm', NS)
                    if xf is not None and any(k in xf.attrib for k in ('rot','flipH','flipV')):
                        warnings.append('Picture transform present: inspect rendered slide')
                except (OSError, ValueError):
                    warnings.append('Unsupported image: ' + target)
            pics.sort(reverse=True)
            image = None
            if pics:
                im = ImageOps.exif_transpose(Image.open(io.BytesIO(z.read(pics[0][1])))).convert('RGB')
                im.thumbnail((1600,1600), Image.Resampling.LANCZOS)
                image = f'images/{pid}.jpg'
                im.save(output / image, quality=90, subsampling=0)
                if len(pics) > 1 and pics[1][0] > pics[0][0] * .2:
                    warnings.append('Multiple substantial images: largest-image draft may omit content')
            else:
                warnings.append('No usable image')
            audios = sorted({v[1] for v in rel.values() if v[0] in ('audio','media') and Path(v[1]).suffix.lower() in ('.mp3','.m4a','.wav','.aac','.ogg')})
            audio = None
            if len(audios) == 1:
                audio = f'audio/{pid}{Path(audios[0]).suffix.lower()}'
                (output / audio).write_bytes(z.read(audios[0]))
            elif len(audios) > 1:
                warnings.append('Multiple audio candidates; no automatic selection')
            else:
                warnings.append('No embedded audio')
            if not text:
                warnings.append('No text layer; inspect image, do not invent text')
            pages.append(dict(id=pid, sourcePage=i, kind='unclassified', text=text, textSource='pptx-text' if text else 'none', image=image, audio=audio, imageReview='pending', audioReview='pending' if audio else 'not_applicable'))
            evidence.append(dict(pageId=pid, slidePart=part, imageCandidates=[dict(part=p[1],width=p[2],height=p[3]) for p in pics], audioCandidates=audios, warnings=warnings))
        book = dict(schemaVersion=1,contentVersion=1,id=book_id,title=title,language='en',level=None,cover=pages[0]['image'] if pages else None,source=dict(filename=src.name,sha256=hashlib.sha256(src.read_bytes()).hexdigest()),pages=pages,playablePageIds=[],verification=dict(status='draft',note='Extracted only. Visual and listening review required.'))
        (output/'book.json').write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        (output/'review.json').write_text(json.dumps(dict(pages=evidence),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(output=str(output),pages=len(pages),audio=sum(bool(p['audio']) for p in pages))))

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--id',required=True);p.add_argument('--title',required=True)
    a=p.parse_args();extract(a.source,a.output,a.id,a.title)
