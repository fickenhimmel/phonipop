"""Build draft RAZ books from matched text-layer and point-reading PDFs."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

from PIL import Image
from pypdf import PdfReader
from pypdf.errors import PdfReadError

from validate_pack import validate


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalized(text):
    return ''.join(c for c in unicodedata.normalize('NFKC', text).casefold() if c.isalnum())


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def text_layout(path, pdftotext):
    extracted = subprocess.run([pdftotext, '-bbox-layout', str(path), '-'], check=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for sheet in ET.fromstring(extracted.stdout).findall('.//{*}page'):
        lines = []
        for line in sheet.findall('.//{*}line'):
            words = ' '.join(w.text or '' for w in line.findall('{*}word')).strip()
            box = tuple(float(line.attrib[k]) for k in ('xMin', 'yMin', 'xMax', 'yMax'))
            if words:
                lines.append((words, box))
        yield float(sheet.attrib['width']), float(sheet.attrib['height']), lines


def audio_specs(annotation):
    subtype = annotation.get('/Subtype')
    if subtype == '/Screen' and '/A' in annotation:
        action = annotation['/A']
        if action.get('/S') == '/Rendition':
            media = action['/R']['/C']
            if media.get('/CT') == 'audio/mpeg':
                yield media['/D']
    elif subtype == '/RichMedia' and '/RichMediaContent' in annotation:
        media = annotation['/RichMediaContent']
        configurations = media.get('/Configurations')
        if not configurations or not any(c.get_object().get('/Subtype') == '/Sound'
                                          for c in configurations.get_object()):
            return
        assets = media['/Assets'].get('/Names')
        if assets:
            for spec_ref in assets.get_object()[1::2]:
                spec = spec_ref.get_object()
                if str(spec.get('/F', '')).lower().endswith('.mp3'):
                    yield spec


def read_clips(path, title, level):
    pdf = PdfReader(path)
    clips = {}
    families = set()
    for source_page, page in enumerate(pdf.pages, 1):
        specs = (spec for ref in page.get('/Annots') or () for spec in audio_specs(ref.get_object()))
        for spec in specs:
            filename = str(spec['/F'])
            match = re.fullmatch(r'(.+?)_(title|p(\d+))_text\.mp3', filename, re.I)
            if not match:
                raise ValueError(f'Unrecognized audio name on PDF page {source_page}: {filename}')
            family = match.group(1)
            families.add(family.casefold())
            if normalized(title) not in normalized(family):
                raise ValueError(f'Audio title cannot be confirmed from {filename}')
            code = re.search(r'(?:^|_)l(aa|[a-z]\d?)\d{2}(?:_|$)', family, re.I)
            if code and code.group(1).casefold() != level.casefold():
                raise ValueError(f'Audio level does not match the book level: {filename}')
            if match.group(3) is None:
                if source_page not in (1, 2):
                    raise ValueError(f'Title audio on unexpected PDF page {source_page}')
            number = int(match.group(3)) if match.group(3) is not None else source_page
            if number != source_page or number in clips:
                raise ValueError(f'Audio number and attached PDF page disagree or duplicate: {filename}')
            data = spec['/EF']['/F'].get_data()
            if len(data) < 256 or not (data.startswith(b'ID3') or data[0] == 255 and data[1] & 224 == 224):
                raise ValueError(f'Invalid MP3 stream on PDF page {source_page}: {filename}')
            clips[number] = filename, data
    if len(families) != 1:
        raise ValueError('Missing audio family or multiple audio families')
    return len(pdf.pages), clips


def find_body(lines, title, printed_page, height):
    numerals = [(text, box) for text, box in lines if text.isdecimal() and box[1] > height * 0.84]
    if len(numerals) != 1 or int(numerals[0][0]) != printed_page:
        raise ValueError(f'Could not confirm printed page {printed_page}: {[t for t, _ in numerals]}')
    footer = re.compile(r'^' + re.escape(normalized(title)) + r'level(?:aa|[a-z]\d?)$')
    body = [(text, box) for text, box in lines if (text, box) not in numerals and not
            (box[1] > height * 0.84 and footer.fullmatch(normalized(text)))]
    if not body:
        raise ValueError(f'Printed page {printed_page} has no extractable text')
    if any(box[1] < height * 0.35 for _, box in body):
        raise ValueError(f'Printed page {printed_page} has text above or inside the illustration region')
    body.sort(key=lambda line: (line[1][1], line[1][0]))
    return ' '.join(text for text, _ in body), min(box[1] for _, box in body)


def convert(entry, manifest_root, result, args):
    bid, title, level = (entry[k] for k in ('id', 'title', 'level'))
    version = entry.get('contentVersion', 1)
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,99}', bid) or not title.strip():
        raise ValueError('Invalid book id or title')
    if not re.fullmatch(r'aa|[A-Z]\d?', level) or type(version) is not int or version < 1:
        raise ValueError('Invalid level or contentVersion')
    color, point = (manifest_root / entry[k] for k in ('color', 'point'))
    final = result / bid
    if final.exists():
        raise FileExistsError(f'Output already exists: {final}')
    layout = list(text_layout(color, args.pdftotext))
    point_count, clips = read_clips(point, title, level)
    if len(layout) < 3:
        raise ValueError('Too few color PDF pages')
    if len(layout) == point_count:
        panels = [(n, 'full', 'story') for n in range(3, len(layout))]
        panels = [(1, 'full', 'cover'), (2, 'full', 'title'), *panels,
                  (len(layout), 'full', 'credits')]
    elif point_count == (len(layout) - 2) * 2 + 3:
        if all(w > h for w, h, _ in layout):
            first, second, front, back = 'left', 'right', 'right', 'left'
        elif all(h > w for w, h, _ in layout):
            first, second, front, back = 'top', 'bottom', 'top', 'bottom'
        else:
            raise ValueError('Mixed sheet orientations need a manual page map')
        panels = [(1, front, 'cover'), (2, first, 'title')]
        panels += [(n, side, 'story') for n in range(3, len(layout) + 1) for side in (first, second)]
        panels += [(2, second, 'credits'), (1, back, 'unclassified')]
    else:
        raise ValueError(f'Unsupported layout or differing editions: {len(layout)} color sheets, {point_count} audio PDF pages')
    story_numbers = {i for i, (_, _, kind) in enumerate(panels, 1) if kind == 'story'}
    body_clips = set(clips) - {1, 2}
    if body_clips != story_numbers:
        raise ValueError(f'Audio coverage mismatch: missing {sorted(story_numbers - clips.keys())}, '
                         f'unexpected {sorted(body_clips - story_numbers)}')

    def panel_data(number, side):
        width, height, lines = layout[number - 1]
        left, top, right, bottom = {
            'full': (0, 0, width, height), 'left': (0, 0, width / 2, height),
            'right': (width / 2, 0, width, height), 'top': (0, 0, width, height / 2),
            'bottom': (0, height / 2, width, height),
        }[side]
        rotate = side == 'bottom' and number != 1
        local = []
        for text, (x0, y0, x1, y1) in lines:
            if not (left <= (x0 + x1) / 2 < right and top <= (y0 + y1) / 2 < bottom):
                continue
            if side != 'full' and (x0 < left - 2 or x1 > right + 2 or y0 < top - 2 or y1 > bottom + 2):
                raise ValueError(f'Text crosses panel boundary on PDF sheet {number}')
            box = ((right-x1, bottom-y1, right-x0, bottom-y0) if rotate else
                   (x0-left, y0-top, x1-left, y1-top))
            local.append((text, box))
        return (width, height), (left, top, right, bottom), rotate, local

    for sheet, side, _ in panels[:2]:
        _, _, _, lines = panel_data(sheet, side)
        if normalized(title) not in normalized(' '.join(t for t, _ in lines)):
            raise ValueError(f'Color PDF title cannot be confirmed on sheet {sheet}')
    _, _, _, cover_lines = panel_data(*panels[0][:2])
    cover_label = ' '.join(t for t, _ in cover_lines)
    level_marker = r'\bleveled\s+(?:book|reader)\s*[•·●:\-]?\s*' + re.escape(level) + r'\b'
    if not re.search(level_marker, cover_label, re.I):
        raise ValueError(f'Color PDF cover does not confirm level {level}')

    with tempfile.TemporaryDirectory(prefix='.raz-', dir=result) as tmp:
        work = Path(tmp)
        staged = work / bid
        (staged / 'images').mkdir(parents=True)
        (staged / 'audio').mkdir()
        subprocess.run([args.pdftoppm, '-scale-to', '1600', '-png', str(color), str(work/'sheet')],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        rendered = sorted(work.glob('sheet-*.png'))
        if len(rendered) != len(layout):
            raise ValueError('Rendered sheet count does not match text layout')
        pages, evidence = [], []
        for i, (sheet, side, kind) in enumerate(panels, 1):
            pid = f'p{i:03d}'
            (width, height), panel, rotate, lines = panel_data(sheet, side)
            left, top, right, bottom = panel
            panel_height = bottom - top
            crop_height = panel_height
            text = title if kind in ('cover', 'title') else ''
            audio = None
            audio_source = None
            if kind == 'story':
                text, crop_height = find_body(lines, title, i, panel_height)
                # Keep the full illustration area above text; a visual review checks for overlap.
            if i in clips:
                filename, data = clips[i]
                audio = f'audio/{pid}.mp3'
                (staged/audio).write_bytes(data)
                audio_source = dict(type='embedded', container='PDF', filename=filename,
                                    sourcePage=i, audioSha256=digest(data))
            rel_image = f'images/{pid}.jpg'
            with Image.open(rendered[sheet-1]) as image:
                pixels = (round(left * image.width / width), round(top * image.height / height),
                          round(right * image.width / width),
                          round(bottom * image.height / height))
                art = image.convert('RGB').crop(pixels)
                if rotate:
                    art = art.transpose(Image.Transpose.ROTATE_180)
                art = art.crop((0, 0, art.width, round(art.height * crop_height / panel_height)))
                art.save(staged/rel_image, quality=94, subsampling=0)
            pages.append(dict(id=pid, sourcePage=i, kind=kind, text=text,
                              textSource='pdf-text-layer' if text else 'not_applicable',
                              image=rel_image, imageContainsText=kind != 'story', imageReview='pending',
                              audio=audio, audioSource=audio_source,
                              audioReview='pending' if audio else 'not_applicable'))
            evidence.append(dict(pageId=pid, colorPdfPage=sheet, colorPanel=side, panelPixels=pixels,
                                 rotationDegrees=180 if rotate else 0, visibleHeightPixels=art.height,
                                 colorPrintedPage=i if kind == 'story' else None, pointAudio=audio_source,
                                 pendingTasks=['Check crop and layout against the source.',
                                               'Check extracted sentence and listen for page alignment.']
                                 if audio else ['Check original panel and orientation.']))
        sources = {k: dict(filename=p.name, sha256=digest(p.read_bytes()))
                   for k, p in [('color', color), ('point', point)]}
        book = dict(schemaVersion=1, contentVersion=version, id=bid, title=title, language='en',
                    level=level, classificationSource='source-cover', cover=pages[0]['image'],
                    source=sources['color'], pages=pages,
                    playablePageIds=[p['id'] for p in pages if p['kind'] == 'story'],
                    verification=dict(status='draft', note='Paired color PDF and embedded MP3. Visual and listening review pending.'))
        if entry.get('genre') in ('fiction', 'nonfiction'):
            book['genre'] = entry['genre']
            book['genreSource'] = entry['genreSource']
        write_json(staged/'book.json', book)
        write_json(staged/'review.json', dict(bookId=bid, sources=sources, colorPdfSheets=len(layout),
                   pointPdfPages=point_count, pages=evidence, audioReview='pending_listening',
                   appImportReview='pending_device_import'))
        check = validate(staged)
        if check['errors']:
            raise ValueError('; '.join(check['errors']))
        staged.rename(final)
    return dict(id=bid, status='draft', storyPages=len(story_numbers), output=str(final))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path, help='JSON array of matched PDF pairs')
    parser.add_argument('output', type=Path)
    parser.add_argument('--pdftotext', default='pdftotext')
    parser.add_argument('--pdftoppm', default='pdftoppm')
    args = parser.parse_args()
    for tool in (args.pdftotext, args.pdftoppm):
        if not shutil.which(tool):
            parser.error(f'Poppler executable not found: {tool}')
    entries = json.loads(args.manifest.read_text(encoding='utf-8'))
    if not isinstance(entries, list) or not entries or any(not isinstance(x, dict) for x in entries):
        parser.error('Manifest must be a nonempty JSON array of objects')
    ids = [x.get('id') for x in entries]
    if any(not isinstance(i, str) for i in ids) or len(set(ids)) != len(ids):
        parser.error('Manifest book ids must be present and unique')
    args.output.mkdir(parents=True, exist_ok=True)
    summary = []
    for entry in entries:
        try:
            summary.append(convert(entry, args.manifest.resolve().parent, args.output, args))
        except (ValueError, OSError, KeyError, TypeError, PdfReadError, ET.ParseError, subprocess.SubprocessError) as exc:
            item = dict(id=entry['id'], status='needs_review', reason=str(exc))
            if isinstance(exc, subprocess.CalledProcessError) and exc.stderr:
                item['detail'] = exc.stderr.decode(errors='replace').strip()[-800:]
            summary.append(item)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return int(any(item['status'] == 'needs_review' for item in summary))


if __name__ == '__main__':
    raise SystemExit(main())
