"""Validate content references and learning sequence, not semantic accuracy."""
import json
import re
import sys
from pathlib import Path, PurePosixPath
from PIL import Image

def validate(root):
    root=Path(root).resolve()
    b=json.loads((root/'book.json').read_text(encoding='utf-8'))
    errors=[]
    def resource(value, label, image=False):
        if not isinstance(value,str) or not value or '\\' in value or ':' in value or PurePosixPath(value).is_absolute() or '..' in PurePosixPath(value).parts:
            errors.append(f'{label}: invalid relative path');return
        file=(root/value).resolve()
        if not file.is_relative_to(root) or not file.is_file() or file.stat().st_size==0:
            errors.append(f'{label}: missing/empty/outside file');return
        if file.suffix.lower() not in (('.jpg','.jpeg','.png','.webp') if image else ('.mp3','.m4a','.wav')):errors.append(f'{label}: unsupported media format')
        if image:
            try:
                with Image.open(file) as im:im.verify()
            except Exception as e:errors.append(f'{label}: invalid image {e}')
    if b.get('schemaVersion')!=1:errors.append('Unsupported schemaVersion')
    if not isinstance(b.get('contentVersion'),int) or b['contentVersion']<1:errors.append('Invalid contentVersion')
    for field in ('id','title','language'):
        if not b.get(field):errors.append('Missing '+field)
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,99}',str(b.get('id',''))):errors.append('Invalid stable book id')
    for field in ('level','grade'):
        if field in b and not isinstance(b[field],str):errors.append('Invalid '+field)
    if 'genre' in b and b['genre'] not in ('fiction','nonfiction'):errors.append('Invalid genre')
    pages=b.get('pages',[]); ids=[p.get('id') for p in pages]
    if not pages or len(set(ids))!=len(ids) or not all(ids):errors.append('Missing or duplicate page ids')
    resource(b.get('cover'),'cover',True)
    for i,p in enumerate(pages,1):
        if p.get('sourcePage')!=i:errors.append('Unexpected source order '+str(p.get('id')))
        if p.get('kind') not in ('unclassified','cover','title','story','credits'):errors.append('Invalid page kind')
        resource(p.get('image'),str(p.get('id'))+' image',True)
        if p.get('audio') is not None:resource(p['audio'],str(p.get('id'))+' audio')
    seq=b.get('playablePageIds',[])
    if len(set(seq))!=len(seq):errors.append('Duplicate learning page')
    indices=[]
    for pid in seq:
        if pid not in ids:errors.append('Unknown learning page '+pid);continue
        index=ids.index(pid);indices.append(index);p=pages[index]
        if p.get('kind')!='story' or not p.get('text') or not p.get('audio'):errors.append('Incomplete learning page '+pid)
    if indices!=sorted(indices):errors.append('Learning sequence out of order')
    if b.get('verification',{}).get('status')=='reviewed':
        if not seq:errors.append('Reviewed book has no learning sequence')
        for p in pages:
            if p.get('imageReview')!='verified' or (p.get('audio') and p.get('audioReview')!='verified'):errors.append('Reviewed status conflicts with pending page '+p['id'])
    return dict(structuralValidation='pass' if not errors else 'fail',errors=errors,pages=len(pages),learningPages=len(seq),audioFiles=sum(bool(p.get('audio')) for p in pages),verification=b.get('verification'),bytes=sum(p.stat().st_size for p in root.rglob('*') if p.is_file()))

if __name__=='__main__':
    result=validate(sys.argv[1]);print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['errors']))
