"""Create an importable ZIP, after structural validation. Never changes source packs."""
import argparse,json,zipfile,re
from pathlib import Path
from validate_pack import validate
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('books',nargs='+',type=Path);a=p.parse_args()
if a.output.exists():p.error('Output exists; choose a new output name')
ids=set();files=[];total=0
for root in a.books:
 result=validate(root)
 if result['errors']:p.error(str(root)+': '+str(result['errors']))
 b=json.loads((root/'book.json').read_text())
 if b['id'] in ids:p.error('Duplicate book id: '+b['id'])
 ids.add(b['id'])
 for f in sorted(root.rglob('*')):
  if f.is_symlink():p.error('Symbolic links are not supported')
  if not f.is_file() or f.name.startswith('.'):continue
  if f.stat().st_size>64*1024*1024:p.error('File exceeds 64 MB: '+str(f))
  total+=f.stat().st_size;files.append((f,b['id']+'/'+f.relative_to(root).as_posix()))
if len(ids)>100 or len(files)>10000 or total>512*1024*1024:p.error('Import limit exceeded: 100 books, 10000 files, 512 MB uncompressed')
a.output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.output,'x',zipfile.ZIP_DEFLATED) as z:
 for f,name in files:z.write(f,name)
print(json.dumps(dict(zip=str(a.output),books=len(ids),files=len(files),uncompressedBytes=total,review='Structural checks only; source review status preserved'),ensure_ascii=False))
