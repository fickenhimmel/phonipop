"""Fill missing story audio using local macOS speech; publish a new validated pack."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path
from validate_pack import validate


def synthesize(source, output, voice='Ava (Enhanced)', rate=90, text_reviewed=False):
    source, output = Path(source).resolve(), Path(output).resolve()
    if not text_reviewed:
        raise ValueError('Visually verify every story sentence, then pass --text-reviewed')
    if output.exists() or output.is_relative_to(source):
        raise ValueError('Choose a new output directory outside the input pack')
    if any(p.is_symlink() for p in source.rglob('*')):
        raise ValueError('Symlinks are not supported')
    checked = validate(source)
    if checked['errors']:
        raise ValueError(checked['errors'])
    book = json.loads((source/'book.json').read_text())
    if book.get('language') not in ('en', 'en-US', 'en-GB'):
        raise ValueError('This backend supports English books only')
    if not 80 <= rate <= 220:
        raise ValueError('Rate must be 80–220 words per minute')
    voices = subprocess.run(['/usr/bin/say', '-v', '?'], check=True, capture_output=True, text=True, timeout=30).stdout
    if not any(re.match(re.escape(voice)+r'\s+en[_-]', line) for line in voices.splitlines()):
        raise ValueError('Requested English voice is unavailable: '+voice)
    targets = [p for p in book['pages'] if p['kind']=='story' and not p.get('audio')]
    if not targets:
        raise ValueError('No missing story audio; input left unchanged')
    for page in targets:
        if not page.get('text','').strip() or '[[' in page['text'] or ']]' in page['text']:
            raise ValueError('Empty text or speech control markup: '+page['id'])
        if not re.fullmatch(r'[a-zA-Z0-9_-]+', page['id']):
            raise ValueError('Unsafe page id')
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.tts-', dir=output.parent) as temporary:
        work=Path(temporary); pack=work/'pack'; shutil.copytree(source,pack)
        (pack/'audio').mkdir(exist_ok=True)
        review_path=pack/'review.json'
        review=json.loads(review_path.read_text()) if review_path.exists() else {'pages':[]}
        for page in targets:
            relative='audio/'+page['id']+'-synthetic.wav'; audio=pack/relative
            if audio.exists():
                raise FileExistsError(relative)
            textfile=work/'sentence.txt'; textfile.write_text(page['text'],encoding='utf-8')
            aiff=work/'speech.aiff'
            if aiff.exists(): aiff.unlink()
            subprocess.run(['/usr/bin/say','-v',voice,'-r',str(rate),'-f',str(textfile),'-o',str(aiff)],check=True,timeout=60)
            subprocess.run(['/usr/bin/afconvert',str(aiff),str(audio),'-f','WAVE','-d','LEI16@22050','-c','1'],check=True,timeout=60)
            with wave.open(str(audio),'rb') as wav:
                duration=wav.getnframes()/wav.getframerate()
                frames=wav.readframes(wav.getnframes())
                if duration<.1 or not any(frames): raise ValueError('Empty/silent synthesis')
            meta={'type':'synthetic','engine':'macOS say','voice':voice,'language':book['language'],'rateWpm':rate,'textSha256':hashlib.sha256(page['text'].encode()).hexdigest(),'durationSeconds':round(duration,3),'audioSha256':hashlib.sha256(audio.read_bytes()).hexdigest()}
            page.update(audio=relative,audioStatus='available',audioSource=meta,audioReview='pending')
            entry=next((e for e in review.get('pages',[]) if e.get('pageId')==page['id']),None)
            if entry is None:
                entry={'pageId':page['id']};review.setdefault('pages',[]).append(entry)
            entry['synthesizedAudio']=meta
            entry['pendingTasks']=['Listen and verify exact wording, pronunciation, completeness and clarity.']
        book['contentVersion']+=1
        book['playablePageIds']=[p['id'] for p in book['pages'] if p['kind']=='story' and p.get('text') and p.get('image') and p.get('audio')]
        book['verification']={'status':'draft','note':'Missing story audio synthesized locally; existing audio preserved. Listening review pending; no word timestamps.'}
        review['audioRevision']={'generatedPages':[p['id'] for p in targets],'engine':'macOS say','status':'listening_pending','note':'Earlier missing-audio observations, if present, describe the input. Current availability is in book.json.'}
        for name,obj in [('book.json',book),('review.json',review)]:
            (pack/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        result=validate(pack)
        if result['errors']: raise ValueError(result['errors'])
        if output.exists(): raise FileExistsError(output)
        pack.rename(output)
    return {'output':str(output),'generatedPages':len(targets),'contentVersion':book['contentVersion'],'verification':'draft'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--voice',default='Ava (Enhanced)');parser.add_argument('--rate',type=int,default=90)
    parser.add_argument('--text-reviewed',action='store_true',help='Assert all story text was visually checked against the source')
    args=parser.parse_args()
    print(json.dumps(synthesize(args.source,args.output,args.voice,args.rate,args.text_reviewed),ensure_ascii=False))
