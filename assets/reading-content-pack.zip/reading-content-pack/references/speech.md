# 逐页合成朗读

当前可执行后端为 macOS 自带 say + afconvert，离线运行，不需 API 密钥。只支持英文书；默认 Samantha（优化音质，美式英语；say 音色 ID 为 `Samantha (Enhanced)`）、90 词/分钟，可用 --voice 和 --rate 调整。先用 `say -v '?'` 查看已安装英文音色，不擅自替换语言或下载音色。系统音色未必达到自然教师朗读质量，先生成一本试听样本，再批量运行。

每个正文页对应一个单声道 22050 Hz、16 bit PCM WAV；直接读已核对的原句，不加介绍、页码、翻译或额外提示。不能改写句子来迁就 TTS，也不能把整词朗读当作音素教学。含生僻词、缩写、角色对话的页面重点核听。

```sh
python3 scripts/synthesize_audio.py '/path/book-v2' '/path/book-v3' --text-reviewed --voice "Samantha (Enhanced)" --rate 90
python3 scripts/validate_pack.py '/path/book-v3'
python3 scripts/package_books.py '/path/books-with-audio.zip' '/path/book-v3'
```

--text-reviewed 表示调用者确已对照原页核对全部正文。只补 kind=story 且 audio 为空的页面；现有音频保持不变。若路径已填写但文件缺失，先报告并修复来源关系，不能默默用合成替换。新建输出目录，原包保持不变；同一 id 的 contentVersion 加 1。失败不发布半成品目录，临时生成文件清理。WAV 比压缩音频体积大，打包仍需满足导入体积限制。

每页 audioSource 记录 type=synthetic、engine、voice、language、rateWpm、textSha256、audioSha256 和 durationSeconds；原始录音不会被伪装成合成，合成也不得宣称原版。生成后更新 playablePageIds，audioReview=pending、verification.status=draft。结构校验和 PCM 非空检测不代替逐页听感审核；无法试听则明确交付“合成朗读待试听草稿”。没有真实对齐结果不提供词级时间戳。

如果用户需要云端或更自然的指定音色，先说明所需服务、文本上传和费用，再按用户授权采用；本脚本不提供云端调用。用户只要求更新 skill 时，用隔离样本验证能力，不自动给已有全部书包配音。

## 非英语母语儿童跟读

默认 90 词/分钟，适合需要较慢跟读节奏的初学儿童；如用户希望稍快，可调至 --rate 100。实际节奏随音色、句长和标点变化，先试听代表性短句与长句，再决定是否批量生成；不能仅凭速率参数断言适龄。保持自然连读、清晰发音及原句标点，不插入逐词断句，不改写原文，不生成机械逐字朗读。该模式是整句朗读，不代替音素示范。已有原版录音不自动变速；用户要求重做旧合成音频时，保留旧包、使用同一书籍 ID 和更高版本，确认旧 audioSource 为 synthetic 后才在工作副本中清空相应 audio，再运行生成脚本。

## Samantha 版本识别

默认只选 Samantha（优化音质 / Enhanced）。普通版通常显示为 `Samantha` 或 `Samantha (英语（美国）)`，不能当作优化版。`say -v '?'` 列表须精确匹配 `Samantha (Enhanced)` 和英文语言标识；只有普通版时停止并说明需要下载优化版，不自动回退。若系统本地化名称不同，先用 AVSpeechSynthesisVoice 核实完整 identifier 和 quality，再显式传入对应的 `--voice`。优化版标识为 `com.apple.voice.enhanced.en-US.Samantha`、quality=2；`compact` 或 `super-compact`、quality=1 均为普通版。资源目录中的预览文件不能证明完整音色已安装可用。

记录实际使用的完整音色名称，不将普通版生成的文件标为 Enhanced。新音色先制作试听样本，确认听感后再批量重制既有书包。
